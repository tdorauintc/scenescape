user_pref("network.http.spdy.websockets", false);
